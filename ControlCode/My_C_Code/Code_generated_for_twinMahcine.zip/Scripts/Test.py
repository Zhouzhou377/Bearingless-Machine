import numpy as np
import sys
sys.path.append(r'..\AMDC-Firmware\scripts')
print("printing lists in new line")
for x in range(len(sys.path)):
    print(sys.path[x]),
#ifndef CMD_INV_H
#define CMD_INV_H

void cmd_inv_register(void);

int cmd_inv(int argc, char **argv);

#endif // CMD_INV_H

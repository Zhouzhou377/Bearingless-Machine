#ifndef CMD_DTC_H
#define CMD_DTC_H

void cmd_dtc_register(void);

int cmd_dtc(int argc, char **argv);

#endif // CMD_DTC_H

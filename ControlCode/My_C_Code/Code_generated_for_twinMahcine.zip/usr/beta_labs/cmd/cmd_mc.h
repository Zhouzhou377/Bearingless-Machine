#ifndef CMD_MC_H
#define CMD_MC_H

void cmd_mc_register(void);

int cmd_mc(int argc, char **argv);

#endif // CMD_MC_H

#ifndef CMD_BEMFO_H
#define CMD_BEMFO_H

void cmd_bemfo_register(void);

int cmd_bemfo(int argc, char **argv);

#endif // CMD_BEMFO_H

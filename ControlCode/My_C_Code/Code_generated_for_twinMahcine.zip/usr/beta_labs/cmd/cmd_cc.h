#ifndef CMD_CC_H
#define CMD_CC_H

void cmd_cc_register(void);

int cmd_cc(int argc, char **argv);

#endif // CMD_CC_H

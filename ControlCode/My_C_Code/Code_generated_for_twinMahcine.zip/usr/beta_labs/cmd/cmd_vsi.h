#ifndef CMD_VSI_H
#define CMD_VSI_H

void cmd_vsi_register(void);

int cmd_vsi(int argc, char **argv);

#endif // CMD_VSI_H

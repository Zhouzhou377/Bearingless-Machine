#ifndef MC_H
#define MC_H

void mc_init(void);
double mc_update(double delta_theta_m_star, double delta_theta_m, double Ts);

#endif // MC_H

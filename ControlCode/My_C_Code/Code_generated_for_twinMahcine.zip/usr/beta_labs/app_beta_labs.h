#ifndef APP_BETA_LABS_H
#define APP_BETA_LABS_H

void app_beta_labs_init(void);

#endif // APP_BETA_LABS

#ifndef APP_BLINK_H
#define APP_BLINK_H

void app_blink_init(void);

#endif // APP_BLINK_H

#ifndef USER_APPS_H
#define USER_APPS_H
#include "usr/user_config.h"


void user_apps_init(void);

//void app_cabinet_test_init(void);

#endif // USER_APPS_H

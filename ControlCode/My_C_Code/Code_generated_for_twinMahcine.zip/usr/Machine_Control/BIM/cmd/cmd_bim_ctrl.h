#ifndef CMD_BIM_CTRL
#define CMD_BIM_CTRL


void cmd_bim_register(void);
int cmd_bim(int argc, char **argv);

#endif // CMD_TWIN_CTRL

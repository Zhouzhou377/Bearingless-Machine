#ifndef bim_LOG_H
#define bim_LOG_H
#include "usr/Machine_Control/BIM/bim_outloop_control.h"

void bim_log (bim_control *data);

#endif

#ifndef CMD_CABINET_H
#define CMD_CABINET_H


void cmd_cabinet_register(void);
int cmd_cabinet(int argc, char **argv);

#endif // CMD_CABINET_H

#ifndef CMD_C_LOOP_CTRL_H
#define CMD_C_LOOP_CTRL_H


void cmd_c_loop_register(void);
int cmd_c_loop(int argc, char **argv);

#endif // CMD_TWIN_CTRL

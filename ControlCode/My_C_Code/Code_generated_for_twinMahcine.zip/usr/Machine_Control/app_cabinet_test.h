#ifndef APP_CABINET_TEST_H
#define APP_CABINET_TEST_H


void app_cabinet_test_init(void);

#endif // APP_CABINET_TEST_H

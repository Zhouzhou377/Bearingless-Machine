#ifndef C_LOOP_LOG_H
#define C_LOOP_LOG_H
#include "usr/Machine_Control/currentloop_control.h"

void c_loop_log (currentloop_control *data);

#endif

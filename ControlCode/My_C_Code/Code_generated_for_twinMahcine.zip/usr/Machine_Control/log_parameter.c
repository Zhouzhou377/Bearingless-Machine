

#include <stdint.h>
#include <stdbool.h>
 double LOG_Iabc1_a = 0.0;
 double LOG_Iabc1_b = 0.0;
 double LOG_Iabc1_c = 0.0;
 double LOG_Iabc2_a = 0.0;
 double LOG_Iabc2_b = 0.0;
 double LOG_Iabc2_c = 0.0;

 double LOG_Itq_d_ref = 0.0;
 double LOG_Itq_q_ref = 0.0;

 double LOG_Is1_x_ref = 0.0;
 double LOG_Is1_y_ref = 0.0;

 double LOG_Itq_d_inject = 0.0;
 double LOG_Itq_q_inject = 0.0;

 double LOG_Is1_x_inject = 0.0;
 double LOG_Is1_y_inject = 0.0;

 double LOG_Itq_d = 0.0;
 double LOG_Itq_q = 0.0;

 double LOG_Is1_x = 0.0;
 double LOG_Is1_y = 0.0;

 double LOG_Itq2_d_inject = 0.0;
 double LOG_Itq2_q_inject = 0.0;

 double LOG_Is2_x_inject = 0.0;
 double LOG_Is2_y_inject = 0.0;

 double LOG_Itq2_d = 0.0;
 double LOG_Itq2_q = 0.0;

 double LOG_Is2_x = 0.0;
 double LOG_Is2_y = 0.0;

 double LOG_Te_ref = 0.0;

 double LOG_wrm = 0.0;
 double LOG_w_test = 0.0;
 double LOG_wrm_ref = 0.0;
 double LOG_wrm_inject = 0.0;
 double LOG_wrm_hf = 0.0;

 double LOG_theta_rm = 0.0;
 double LOG_theta_rm_est = 0.0;


 double LOG_wsl = 0.0;
 double LOG_theta_e = 0.0;
 double LOG_we = 0.0;

 double LOG_Te = 0.0;

 double LOG_vdc_inv1_mes = 0.0;
 double LOG_vdc_inv2_mes = 0.0;
 double LOG_vdc_inv3_mes = 0.0;
 double LOG_vdc_inv4_mes = 0.0;


 double LOG_va1_ref = 0.0;
 double LOG_vb1_ref = 0.0;
 double LOG_vc1_ref = 0.0;

 double LOG_va2_ref = 0.0;
 double LOG_vb2_ref = 0.0;
 double LOG_vc2_ref = 0.0;

 double LOG_vd_ref = 0.0;
 double LOG_vq_ref = 0.0;
 double LOG_v0_ref = 0.0;

 double LOG_vd_inject = 0.0;
 double LOG_vq_inject= 0.0;

 double LOG_vx_ref = 0.0;
 double LOG_vy_ref = 0.0;
 double LOG_vx_inject = 0.0;
 double LOG_vy_inject = 0.0;

 double LOG_vd2_ref = 0.0;
 double LOG_vq2_ref = 0.0;

 double LOG_vd2_inject = 0.0;
 double LOG_vq2_inject= 0.0;

 double LOG_vx2_ref = 0.0;
 double LOG_vy2_ref = 0.0;

 double LOG_vx2_inject = 0.0;
 double LOG_vy2_inject = 0.0;

 double LOG_delta_x = 0.0;
 double LOG_delta_y = 0.0;

 double LOG_F_x = 0.0;
 double LOG_F_y = 0.0;
 double LOG_F_x_inject = 0.0;
 double LOG_F_y_inject = 0.0;
 double LOG_error_x = 0.0;
 double LOG_error_y = 0.0;

 double LOG_delta_x_ref = 0.0;
 double LOG_delta_y_ref = 0.0;

 double LOG_delta_x_ref_lpf = 0.0;
 double LOG_delta_y_ref_lpf = 0.0;


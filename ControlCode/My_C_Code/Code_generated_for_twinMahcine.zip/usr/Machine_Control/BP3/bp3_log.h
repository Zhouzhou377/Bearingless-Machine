#ifndef bp3_LOG_H
#define bp3_LOG_H
#include "usr/Machine_Control/BP3/bp3_outloop_control.h"

void bp3_log (bp3_control *data);

#endif

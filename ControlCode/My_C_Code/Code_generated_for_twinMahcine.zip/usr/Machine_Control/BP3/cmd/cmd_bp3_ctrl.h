#ifndef CMD_BP3_CTRL
#define CMD_BP3_CTRL


void cmd_bp3_register(void);
int cmd_bp3(int argc, char **argv);

#endif // CMD_TWIN_CTRL
